# --- senator:ui ---

# Math: (Score * 5) / 10 = Whole Number || (Score * 5) % 10 = Decimal
scoreboard players operation @s sena_calc = @s sena_nano
scoreboard players operation @s sena_calc *= #5 sena_calc

scoreboard players operation @s sena_dec = @s sena_calc
scoreboard players operation @s sena_dec %= #10 sena_calc

scoreboard players operation @s sena_calc /= #10 sena_calc

# --- Display logic based on state ---

# 1. Normal State (Red text)
execute as @s[tag=!nanomachinebreak,tag=!nanomachineconflict] run title @s actionbar [{"text":"Nanomachines: ","color":"gray"},{"score":{"name":"@s","objective":"sena_calc"},"color":"aqua"},{"text":".","color":"aqua"},{"score":{"name":"@s","objective":"sena_dec"},"color":"aqua"},{"text":"%","color":"aqua"}]

# 2. Conflict State - Holding an item (Yellow text to warn them)
execute as @s[tag=nanomachineconflict,tag=!nanomachinebreak] run title @s actionbar [{"text":"Nanomachines [CONFLICT]: ","color":"gold"},{"score":{"name":"@s","objective":"sena_calc"},"color":"yellow"},{"text":".","color":"yellow"},{"score":{"name":"@s","objective":"sena_dec"},"color":"yellow"},{"text":"%","color":"yellow"}]

# 3. Broken State - Hit 0% (Gray text)
execute as @s[tag=nanomachinebreak] run title @s actionbar [{"text":"Nanomachines [BROKEN]: ","color":"dark_gray"},{"score":{"name":"@s","objective":"sena_calc"},"color":"gray"},{"text":".","color":"gray"},{"score":{"name":"@s","objective":"sena_dec"},"color":"gray"},{"text":"%","color":"gray"}]