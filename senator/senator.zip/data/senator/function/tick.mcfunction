# --- senator:tick ---

# 1. INITIALIZATION & RESET
execute as @a[tag=nanomachine] unless score @s sena_nano matches 0..200 run scoreboard players set @s sena_nano 200

tag @a[tag=nanomachine] remove sena_has_armor
tag @a[tag=nanomachine] remove nanomachineconflict
tag @a[tag=nanomachine] remove nanomachinebreak
tag @a[tag=nanomachine] remove sena_hit

# 2. DETECT STATES (High-performance item checks)

# Check for Armor (If ANY item is in the slot, apply armor tag)
execute as @a[tag=nanomachine] if items entity @s armor.head * run tag @s add sena_has_armor
execute as @a[tag=nanomachine] if items entity @s armor.chest * run tag @s add sena_has_armor
execute as @a[tag=nanomachine] if items entity @s armor.legs * run tag @s add sena_has_armor
execute as @a[tag=nanomachine] if items entity @s armor.feet * run tag @s add sena_has_armor

# Check for Conflict (If ANY item is in the mainhand, apply conflict tag)
execute as @a[tag=nanomachine] if items entity @s weapon.mainhand * run tag @s add nanomachineconflict

# 3. DAMAGE DETECTION & DEPLETION
execute as @a[tag=nanomachine] if score @s sena_dmg matches 1.. run tag @s add sena_hit
execute as @a[tag=nanomachine] if score @s sena_abs matches 1.. run tag @s add sena_hit
execute as @a[tag=nanomachine] if score @s sena_res matches 1.. run tag @s add sena_hit

execute as @a[tag=sena_hit] run scoreboard players remove @s sena_nano 1
execute as @a[tag=sena_hit] run scoreboard players set @s sena_timer 0

scoreboard players reset @a sena_dmg
scoreboard players reset @a sena_abs
scoreboard players reset @a sena_res

execute as @a[tag=nanomachine,scores={sena_nano=..0}] run scoreboard players set @s sena_nano 0

# 4. RECOVERY
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!sena_hit,scores={sena_nano=0..199}] run scoreboard players add @s sena_timer 1

execute as @a[tag=nanomachine,scores={sena_timer=240..}] run scoreboard players add @s sena_nano 2
execute as @a[tag=nanomachine,scores={sena_timer=240..}] run scoreboard players set @s sena_timer 0

execute as @a[tag=nanomachine,scores={sena_nano=201..}] run scoreboard players set @s sena_nano 200

# 5. STATE EVALUATION (BREAK)
execute as @a[tag=nanomachine,scores={sena_nano=0}] run tag @s add nanomachinebreak

# 6. APPLYING BUFFS & DEBUFFS
execute as @a[tag=nanomachinebreak] run effect give @s minecraft:mining_fatigue 1 0 true

# Remove Attributes if conditions are invalid (Has armor OR Break state)
execute as @a[tag=nanomachine,tag=sena_has_armor] run attribute @s armor base set 0
execute as @a[tag=nanomachine,tag=sena_has_armor] run attribute @s armor_toughness base set 0
execute as @a[tag=nanomachine,tag=sena_has_armor] run attribute @s attack_knockback base set 0
execute as @a[tag=nanomachine,tag=sena_has_armor] run attribute @s knockback_resistance base set 0
execute as @a[tag=nanomachine,tag=sena_has_armor] run attribute @s safe_fall_distance base reset
execute as @a[tag=nanomachine,tag=nanomachinebreak] run attribute @s armor base set 0
execute as @a[tag=nanomachine,tag=nanomachinebreak] run attribute @s armor_toughness base set 0
execute as @a[tag=nanomachine,tag=nanomachinebreak] run attribute @s attack_knockback base set 0
execute as @a[tag=nanomachine,tag=nanomachinebreak] run attribute @s knockback_resistance base set 0
execute as @a[tag=nanomachine,tag=nanomachinebreak] run attribute @s safe_fall_distance base reset

# Apply Base Attributes (No armor AND No Break)
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run attribute @s armor base set 40
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run attribute @s armor_toughness base set 35
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run attribute @s knockback_resistance base set 1
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run attribute @s attack_knockback base set 5
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run attribute @s safe_fall_distance base set 50

# Apply Effects (No armor AND No Break)
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run effect give @s minecraft:resistance 1 0 true
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak] run effect give @s minecraft:fire_resistance 1 0 true
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak,tag=!nanomachineconflict] run effect give @s minecraft:saturation 1 0 true
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak,tag=!nanomachineconflict] run effect give @s minecraft:strength 1 9 true
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak,tag=!nanomachineconflict] run effect give @s minecraft:speed 1 1 true
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak,tag=!nanomachineconflict] run effect give @s minecraft:resistance 1 3 true
execute as @a[tag=nanomachine,tag=!sena_has_armor,tag=!nanomachinebreak,tag=!nanomachineconflict] run effect give @s minecraft:jump_boost 1 2 true

# 7. DELEGATE UI
execute as @a[tag=nanomachine] run function senator:ui